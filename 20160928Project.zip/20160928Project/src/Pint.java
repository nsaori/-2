
public class Pint {
	private int x;
	private int y;
	
	public Pint(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	public String toString(){
		return "(" + x + "," + y + ")";
	}
	
}
