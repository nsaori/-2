//2013110023 노다 사오리
public class Test {

	public static void main(String[] args) {
		MyFrame f = new MyFrame();

	}

}
