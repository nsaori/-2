
//2013110023 노다 사오리
import javax.swing.JFrame;

public class MyFrame extends JFrame {
	public MyFrame() {
		this.setTitle("CheckBox practice");
		this.setSize(250, 150);

		this.add(new MyPanel());

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);

	}
}
