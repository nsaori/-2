
//2013110023 노다 사오리

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JPanel;

public class MyPanel extends JPanel implements ItemListener {
	public JButton b;
	public JCheckBox cbIsActive, cbHideShow;

	public MyPanel() {
		cbIsActive = new JCheckBox("버틈 비활성화");
		cbHideShow = new JCheckBox("버튼 감추기");

		b = new JButton("test bitton");

		this.add(cbIsActive);
		this.add(cbHideShow);
		this.add(b);

		// listener 등록
		cbHideShow.addItemListener(this);
		cbIsActive.addItemListener(this);
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		boolean select;
		MyPanel p = new MyPanel();

		if (e.getStateChange() == ItemEvent.SELECTED) {
			select = true;
		} else {
			select = false;
		}

		if (e.getSource() == cbIsActive) {

			// p.b.setEnabled(!p.b.isEnabled());
			b.setEnabled(!select);
		}
		if (e.getSource() == cbHideShow) {
			// p.b.setVisible(!p.b.isVisible());
			b.setVisible(!select);
		}

	}

}
